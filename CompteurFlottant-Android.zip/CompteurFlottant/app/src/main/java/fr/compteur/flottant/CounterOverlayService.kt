package fr.compteur.flottant

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class CounterOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private lateinit var countText: TextView
    private var count = 0
    private val prefs by lazy { getSharedPreferences("counter", MODE_PRIVATE) }
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        count = prefs.getInt("value", 0)
        createBubble()
    }

    private fun createBubble() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(10, 7, 10, 7)
            background = GradientDrawable().apply {
                setColor(Color.argb(235, 28, 36, 49))
                cornerRadius = 48f
                setStroke(1, Color.argb(90, 255, 255, 255))
            }
            elevation = 12f
        }
        val minus = control("−", 18f).apply {
            setOnClickListener { change(-1) }
        }
        countText = TextView(this).apply {
            text = count.toString()
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            minWidth = 42
            setPadding(7, 0, 7, 0)
        }
        val plus = control("+", 20f).apply {
            setOnClickListener { change(1) }
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 18f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(7, 0, 2, 0)
            setOnClickListener { stopSelf() }
        }
        container.addView(minus)
        container.addView(countText)
        container.addView(plus)
        container.addView(close)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 12
            y = 280
        }
        container.setOnTouchListener(DragTouchListener())
        bubble = container
        windowManager.addView(container, params)
    }

    private fun control(label: String, size: Float) = TextView(this).apply {
        text = label
        textSize = size
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        minWidth = 34
        minHeight = 38
    }

    private fun change(delta: Int) {
        count = (count.toLong() + delta).coerceIn(Int.MIN_VALUE.toLong(), Int.MAX_VALUE.toLong()).toInt()
        countText.text = count.toString()
        prefs.edit().putInt("value", count).apply()
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        override fun onTouch(view: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    return true
                }
                MotionEvent.ACTION_UP -> return true
            }
            return false
        }
    }

    override fun onDestroy() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
