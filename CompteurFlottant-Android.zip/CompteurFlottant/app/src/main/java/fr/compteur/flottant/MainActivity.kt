package fr.compteur.flottant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("counter", MODE_PRIVATE) }
    private lateinit var startValue: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(Color.rgb(246, 248, 251))
        }
        val title = TextView(this).apply {
            text = "Compteur Flottant"
            textSize = 27f
            setTextColor(Color.rgb(25, 35, 50))
        }
        val subtitle = TextView(this).apply {
            text = "Un compteur toujours accessible au-dessus de tes applications."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 12, 0, 28)
        }
        val label = TextView(this).apply {
            text = "Chiffre de départ"
            textSize = 16f
            setTextColor(Color.DKGRAY)
        }
        startValue = EditText(this).apply {
            hint = "Ex. 0"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(prefs.getInt("value", 0).toString())
            textSize = 22f
            setSingleLine(true)
        }
        val start = Button(this).apply {
            text = "Afficher la bulle flottante"
            textSize = 16f
            setOnClickListener { startCounter() }
        }
        val stop = Button(this).apply {
            text = "Masquer la bulle"
            setOnClickListener { stopService(Intent(this@MainActivity, CounterOverlayService::class.java)); Toast.makeText(this@MainActivity, "Bulle masquée", Toast.LENGTH_SHORT).show() }
        }
        val note = TextView(this).apply {
            text = "Au premier lancement, Android te demandera d'autoriser l'affichage par-dessus les autres applications. Active l'autorisation pour utiliser la bulle."
            textSize = 14f
            setTextColor(Color.GRAY)
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(label)
        root.addView(startValue, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 24 })
        root.addView(stop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(note)
        setContentView(root)
    }

    private fun startCounter() {
        val value = startValue.text.toString().toIntOrNull()
        if (value == null) {
            Toast.makeText(this, "Entre un nombre valide", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.edit().putInt("value", value).apply()
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "Autorise Compteur Flottant, puis relance la bulle", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, CounterOverlayService::class.java))
        Toast.makeText(this, "Bulle affichée", Toast.LENGTH_SHORT).show()
        finish()
    }
}
