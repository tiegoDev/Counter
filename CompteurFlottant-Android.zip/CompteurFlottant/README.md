# Compteur Flottant (Android)

Application Android native minimale : compteur réglable, bulle déplaçable au-dessus des autres applications, boutons + et −, sauvegarde automatique du nombre.

## Construire l'APK
1. Installer Android Studio (version récente) sur un ordinateur.
2. Ouvrir le dossier `CompteurFlottant` dans Android Studio.
3. Laisser Gradle synchroniser le projet (Android SDK 35 requis).
4. Choisir **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK sera généré dans `app/build/outputs/apk/debug/app-debug.apk`.
6. Transférer l'APK sur le téléphone Android et l'installer. Android peut demander d'autoriser l'installation depuis cette source.
7. Ouvrir l'application, saisir le chiffre initial et toucher **Afficher la bulle flottante**. Autoriser l'affichage par-dessus les autres applications dans les paramètres Android, revenir dans l'application et appuyer à nouveau sur le bouton.

## Utilisation
- `−` diminue le compteur ; `+` l'augmente.
- Faire glisser la bulle pour la déplacer.
- `×` masque la bulle. Rouvrir l'application pour la réafficher.
- Le dernier nombre est mémorisé.

Note : Android et certains fabricants peuvent limiter les services en arrière-plan. Si la bulle disparaît après un redémarrage ou une fermeture forcée, relancer l'application. Le projet n'inclut pas de démarrage automatique après redémarrage.
